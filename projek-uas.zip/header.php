<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Institut Teknologi dan Bisnis Indonesia</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/styles.css" rel="stylesheet">
    <style>
      body {
        padding-top: 60px;
      }
    </style>
  </head>
  <body>
    
  <!-- Awal script Navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top" id="scrollspy">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle Nav</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">PARIWISATA</a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
            <li class="active">
              <a href="index.php"><span class="glyphicon glyphicon-home"></span> Beranda <span class="sr-only">(current)</span></a>
            </li>
        <li class="nav-item">
          <a class="nav-link" href="destinasi.php">Destinasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="paketwisata baru.php">Paket Wisata</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="data-destinasi.php"> Data Destinasi Wisata</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Kontak</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Login</a>
        </li>
      </ul>
    </div>
  </nav>