<?php include "header.php"; ?>

  <meta charset="UTF-8">
  <title> Detail wisata</title>
</head>

<body>
  <div class="container">
    <h1>Bukit Holbung</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="foto/bukit.jpg" class="card-img-top" alt="destinasi 3">
        <p class="card-text">Bukit Holbung terletak di desa Harian,Kabupaten Samosir,Sumatra Utara Bukit holbung merupakan tempat wisata untuk menikmati keindahan Danau Toba.Setiap hari,kawasan ini dikunjungi wisatawan,bahkan kalau Sabtu dan Minggu pengunjung semakin ramai hingga membuat area parkir menjadi penuh. Pengunjung tidak hanya wisatawan lokal saja melainkan juga wisatawan mancanegara yang berasal dari Malaysia,Singapura,dan Negara lainnya.</p>
      </div>
     
    </div>
  </div>

