<?php include "header.php"; ?>

      <div class="jumbotron">
            <div class="container">
                  <div class="row">
                        <div class="col-md-12"> 
                          <h1>PAKET WISATA SAMOSIR</h1>
                        </div>
                  </div>
            </div>
      </div>   
</head>
<body>
<div class="album py-5 bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="card mb-4 shadow-sm">
              <img src="foto/sibea1.jpg" class="card-img-top" alt="Room 1" width="100%">
              <div class="card-body">
                <h5 class="card-title">BUKIT SIBEABEA</h5>
                <p class="card-text"></p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text"></p>
                   <a href="detail sibeabea.php" class="btn btn-primary">view</a>
                   <a href="book.php" class="btn btn-primary">Book Now</a>
                </div>   
                   <p class="card-text"></p>
                   <small class="text-muted">RP 90.000 </small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card mb-4 shadow-sm">
              <img src="foto/bukit.jpg" class="card-img-top" alt="Room 2" width="100%" height="240">
              <div class="card-body">
                <h5 class="card-title">BUKIT HOLBUNG</h5>
                <p class="card-text"></p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text-">
                    <a href="detail holbung.php" class="btn btn-primary">view</a>
                    <a href="book.php" class="btn btn-primary">Book Now</a>
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted">RP 50.000</small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card mb-4 shadow-sm">
              <img src="foto/air terjun.jpg" class="card-img-top" alt="Room 3" width="100%" height="240">
              <div class="card-body">
                <h5 class="card-title">AIR TERJUN EFRATA</h5>
                <p class="card-text"> </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text"></p>
                      <a href="detail efrata.php" class="btn btn-primary">view</a>
                      <a href="book.php" class="btn btn-primary">Book Now</a>
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted">RP 28.000</small>
                </div>
              </div>
            </div>
          </div>
             
  </main>
<script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>