<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pariwisata</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>    
  <div class="row">
      <div class="col-md-4">
        <div class="card mb-4
          <div class="card-body">
            <h5 class="card-title">Retribusi tarif tiket</h5>
            <p class="card-text">Bukit holbung harga tiket masuk per orang Rp.5000 harga tiket kendaraan roda 2 kunjungan wisata Rp.5000 Roda 4 kunjungan wisata Rp.10.000 Roda 2 camping Rp.10.000 Roda 4 Camping Rp.20.000.</p
          </div>
        </div>
      </div>
  </div>
        <script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
      