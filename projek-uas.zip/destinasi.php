<?php include "header.php"; ?><br><br><br>


    <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/sibea-bea.jpg" alt="Destinasi 1" width="100%">
          <div class="card-body">
            <h5 class="card-title">Destinasi 1 Sibeabea</h5>
            <p class="card-text">Deskripsi destinasi 1.</p>
            <a href="wisata sibeabea.php" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/air terjun.jpg" alt="Destinasi 2" width="100%">
          <div class="card-body">
            <h5 class="card-title">Destinasi 2 Air terjun efrata</h5>
            <p class="card-text">Deskripsi destinasi 2.</p>
            <a href="wisata efrata.php" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card mb-4">
          <img class="card-img-top" src="foto/holbung,samosir.jpg" alt="Destinasi 3" width="100%">
          <div class="card-body">
            <h5 class="card-title">Destinasi 3 Bukit holbung</h5>
            <p class="card-text">Deskripsi destinasi 3.</p>
            <a href="wisata holbung.php" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>