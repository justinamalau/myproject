<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-pesanan.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from pemesanan where id_pesanan='$id'");
                $row=$tampil->fetch_assoc();
                ?>

                <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="hidden" name="id_pesanan" value="<?php echo $row['id_pesanan']?>" class="form-control">
                        <input type="text" name="nama" value="<?php echo $row['nama]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" value="<?php echo $row['email]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="telepon">Telepon</label>
                        <input type="number" name="telepon" value="<?php echo $row['telepon]?>" class="form-control">
                    </div>

                      <div class="form-group">
                        <label for="Tgl_Check_Out">Tgl_Check_Out</label>
                       <input type="date" name="Tgl_Check_Out " value="<?php echo $row['Tgl_Check_In]?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="destinasi">Destinasi</label>
                        <select name="destinasi" class="form-control">
                          <option value="sibeabea">sibeabea</option>
                           <option value="Bukit holbung">Bukit holbung</option>
                            <option value="Air Terjun Efrata">Air Terjun Efrata</option>
                             </select>
                    </div>

                    <div class="form-group">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" name="tanggal" class="form-control">
                    </div>



                    <input type="submit" name="kirim" value="SIMPAN" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>