<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id=$_POST['destinasi_id'];
$nama_destina=$_POST['nama_destinasi'];
$lokasi=$_POST['lokasi'];
$deskripsi=$_POST['deskripsi'];
$tanggal_dibuka=$_POST['tanggal_dibuka'];
$telepon=$_POST['telepon'];
$email=$_POST['email'];

$ubah=$koneksi->query("update destinasi set nama_destinasi='$nama_destina', lokasi='$lokasi', deskripsi='$deskripsi', tanggal_dibuka='$tanggal_dibuka', telepon='$telepon', email='$email' where destinasi_id='$id'");

if($ubah==true){

    header("location:tampil-destinasi.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>