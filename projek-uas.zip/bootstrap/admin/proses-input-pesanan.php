<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php
$nama=$_POST['nama'];
$email=$_POST['email']
$telepon=$_POST['telepon'];
$destinasi=$_POST['destinasi'];
$tanggal=$_POST['tanggal'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into pemesanan(nama,email, telepon, destinasi, tanggal) 
                        values ( '$nama', '$email', '$telepon', '$destinasi', '$tanggal',')");

if($simpan==true){

    header("location:tampil-pesanan.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>