<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";
$id_pesanan=['id_pesanan'];
$nama=$_POST['nama'];
$email=$_POST['email']
$telepon=$_POST['telepon'];
$destinasi=$_POST['destinasi'];
$tanggal=$_POST['tanggal'];

$ubah=$koneksi->query("update pemesanan set id_pesanan='$id_pesanan', nama='$nama',email= '$email', telepon='$telepon', destinasi='$destinasi', tanggal='$tanggal', where id_pesanan='$id_pesanan'");

if($ubah==true){

    header("location:tampil-pesanan.php?pesan=editBerhasil");
    
} else{
    echo "Error";
}

?>