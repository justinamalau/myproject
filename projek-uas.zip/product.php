<?php include "header.php"; ?>

       <div class="jumbotron">
            <div class="container">
                  <div class="row">
                        <div class="col-md-12"> 
                          <h1>PRODUCT</h1>
                        </div>
                  </div>
            </div>
      </div>   

      <div class="container">
            <div class="row">
                  <div class="col-md-3">
                        <h4> Mie Kuah</h4>
                        <img src="mie kuah.jpg" width="200" height="200">
                        <h4> Rp. 15.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                   <div class="col-md-3">
                        <h4> Mie Goreng</h4>
                        <img src="miegoreng.jpg" width="200" height="200">
                        <h4> Rp. 12.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                  <div class="col-md-3">
                        <h4> Mie Rebus</h4>
                        <img src="mie rebus.jpg" width="200" height="200">
                        <h4> Rp. 10.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                  <div class="col-md-3">
                        <h4> Mie Tumis</h4>
                        <img src="mie tumis.jpg" width="200" height="200">
                        <h4> Rp. 20.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
            </div>
            <div class="row">
                  <div class="col-md-3">
                        <h4> Mie Kwetiau</h4>
                        <img src="mie Kwetiau.jpg" width="200" height="200">
                        <h4> Rp. 25.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                  <div class="col-md-3">
                        <h4> Mie Goreng Korea</h4>
                        <img src="mie Korea.jpg" width="200" height="200">
                        <h4> Rp. 30.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                  <div class="col-md-3">
                        <h4> Mie Goreng Saus Tiram </h4>
                        <img src="mie-goreng-saus-tiram.jpg" width="200" height="200">
                        <h4> Rp. 17.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
                  <div class="col-md-3">
                        <h4> Mie Instan</h4>
                        <img src="mie instan.jpg" width="200" height="200">
                        <h4> Rp. 10.000 </h4>
                        <input class="btn btn-success btn-lg" type="submit" value="details">
                        <input class="btn btn-success btn-lg" type="submit" value="beli">
                  </div>
            </div>
      </div>
<script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>