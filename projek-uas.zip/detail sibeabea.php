<?php include "header.php"; ?>


<div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="card mb-4

          <div class="card-body">
            <h5 class="card-title">Retribusi tarif tiket</h5>
            <p class="card-text"> Tiket masuk 1 orang Rp.5.000 Dan parkir kendaraan motor Rp.20.000 Mobil Rp.50.000 Bus Rp.15.000 Perlu diperhatikan  harga tiket dan biaya parkir di atas dapat berubah kapan saja.Terutama ketika akhir pekan atau saat liburan nasional tiba.Tempat ini seolah bak sebuah magnet yang memiliki daya tarik kesetiap mata yang memandangnya.</p>
            
            
          </div>
        </div>
      </div>
      <script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

      
