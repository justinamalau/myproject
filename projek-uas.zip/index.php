<?php include "header.php"; ?>

  <div class="jumbotron">
    <h1 class="display-4">SELAMAT DATANG DI WISATA SAMOSIR</h1>
    <p class="lead">Temukan destinasi wisata terbaik di sini.</p>
  </div>

    <!-- Awal script Slider/ Carousel -->
    <div id="contoh-carousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#contoh-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#contoh-carousel" data-slide-to="1"></li>
        <li data-target="#contoh-carousel" data-slide-to="2"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
      <!-- Awal script Slider pertama -->
        <div class="item active">
          <img src="foto/air terjun.jpg" alt="Berisi keterangan gambar" width="80%">
        </div><!-- Akhir script Slider pertama -->


        <!-- Awal script Slider kedua -->
        <div class="item">
          <img src="foto/th.jpg" alt="Berisi keterangan gambar" width="80%">
        </div><!-- Akhir script Slider kedua -->


        <!-- Awal script Slider ketiga -->
        <div class="item">
          <img src="foto/sibea-bea.jpg" alt="Berisi keterangan gambar" width="80%">
        </div><!-- Akhir script Slider ketiga -->


    </div>
    <!-- Awal script Button Geser Kiri dan Kanan -->
    <a class="left carousel-control" href="#contoh-carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
    
    <a class="right carousel-control" href="#contoh-carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a><!-- Akhir script Button Geser Kiri dan Kanan -->
    
    </div><!-- Akhir script Slider/Carousel --><br><br><br>
<?php include "footer.php"; ?>