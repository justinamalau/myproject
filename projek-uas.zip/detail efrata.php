<?php include "header.php"; ?>


<div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="card mb-4"
          <div class="card-body">
            <h5 class="card-title">Retribusi tarif tiket</h5>
            <p class="card-text">Wisata air terjun ini masuk dalam kategori tempat wisata murah karena biaya tiket masuknya relatif terjangaku.Harga masuknya saja tidak lebih dari sepuluh ribu rupiah tiket masuk per orang Rp.8.000,00 parkir kendaraan 2 dan 4 Rp.12.000 tapi harga tarif ini bisa berubah kapan saja sesuai dengan keputusan dan kebijakan pihak pengelolah dan saat musim liburan dan libur akhir pekan.</p>
          </div>
        </div>
      </div>
    </div>
    <script src="bootstrap/js/jQuery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
      