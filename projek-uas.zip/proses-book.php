

<?php

include "koneksi.php";
$nama = $koneksi->real_escape_string($_POST['nama']); 
$email = $koneksi->real_escape_string($_POST['email']); 
$telepon = $koneksi->real_escape_string($_POST['telepon']);
$destinasi = $koneksi->real_escape_string($_POST['destinasi']);
$tanggal = $koneksi->real_escape_string($_POST['tanggal']);


$simpan=$koneksi->query("insert into pemesanan(nama,email,telepon,destinasi,tanggal) 
                        values ('$nama', '$email', '$telepon', '$destinasi', '$tanggal')");

if($simpan==true){

    header("location:book.php?pesan=inputBerhasil");
} else{
    echo "Error";
}

?>