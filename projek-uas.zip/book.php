<?php include "header.php"; ?>

<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-12"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Booking</h2>


				<?php 

					if(@$_GET['pesan']=="inputBerhasil"){

					?>
									<div class="alert alert-success">
									Pemesanan Berhasil , Cek Email Anda!
									</div>
					<?php

					}

					?>

				
					<form action="proses-book.php" method="post">
						<table class="table table-hover">


							<tr>
								<td>Nama
								<input type="text" name="nama" class="form-control input-md" placeholder="" required>
								</td>
							</tr>
							<tr>

								<td>Email
								<input type="text" name="email" class="form-control input-md" placeholder=""required>
								</td>
							</tr>
							<tr>

								<td>Telepon
								<input type="number" name="telepon" class="form-control input-md" placeholder="" required>
								</td>
							</tr>
							<tr>
								<td>Destinasi
								<select name="destinasi" class="form-control">
								           <option value="sibeabea">sibeabea</option>
								           <option value="Bukit holbung">Bukit holbung</option>
								           <option value="Air Terjun Efrata">Air Terjun Efrata</option>
								        </select>
								      </div>
								</td>
							</tr>
							
							<tr>
								<td>Tanggal
								<input type="date" name="tanggal" class="form-control input-md" placeholder="" required>
								</td>
							</tr>
								
								<td>
								<input type="submit" value="Kirim" class="btn btn-lg btn-info"> <input type="reset" value="Batal" class="btn btn-lg btn-warning">
								</td>
							</tr>
						</table>
					</form>
				</div>
      </div>

      
		</div><!-- Akhir Baris -->
		</div><!--  Akhir Page -->
		
<?php include "footer.php"; ?>