<?php include "header.php"; ?>

  <meta charset="UTF-8">
  <title> Detail wisata</title>
</head>

<body>
  <div class="col-md-6">
  <div class="container">
    <h1>Air Terjun Efrata</h1>
    <div class="row">
        <img src="foto/air terjun.jpg" class="card-img-top" alt="destinasi 3">
 <p class="card-text"> Air Terjun Efrata berdekatan dengan Menara Pandang Tele Danau Toba.Oleh karena itu tak heran banyak pengunjung lokal dan mancanegara bila singgah ke Tele maupun Danau Toba,juga singgah ke air terjun tersebut.Sementara itu,air terjun Efrata dengan kawasan yang hijau diapit dengan perbukitan membuat setiap pengunjung yang datang ke sana akan terpesona dengan keindahan alamnya.</p>  
    </div>
     


