<?php include "header.php"; ?>


  <main role="main">
  <div class="jumbotron">
    <h1 class="display-4">SELAMAT DATANG DI WISATA SAMOSIR</h1>
    <p class="lead">Temukan destinasi wisata terbaik di sini.</p>
  </div>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body> 
         <div class="container">
    <div class="container">
    <div class="row">
      <div class="col-md-12"> 
          <div class="carousel slide" id="contoh-carousel" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#contoh-carousel" data-slide-to="0" class="active"></li>
              <li data-target="#contoh-carousel" data-slide-to="1"></li>
              <li data-target="#contoh-carousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
              <div class="item active">
                <img src="foto/sibeabea.jpg" alt="Gambar 1" style="width:100%; height: 400px;">
                <div class="carousel-caption">
                  <h1></h1>
                  <h2></h2>
                </div>
              </div>
              <div class="item">
                <img src="foto/holbung.jpg" alt="Gambar 1" style="width:100%; height: 400px;">
                <div class="carousel-caption">
                <h1></h1>
                  <h2></h2>
                  <p>
                </div>
              </div>
            </div>
            <a class="left carousel-control" href="#contoh-carousel" role="button" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
              <span class="sr-only">Prev</span>
            </a>
            <a class="right carousel-control" href="#contoh-carousel" role="button" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
      </div>
</div>

      </div>
    </div>
  </div>
    

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>