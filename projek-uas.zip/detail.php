<?php include "header.php"; ?>

      <div class="container">
      </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="sibeabea.jpg" class="card-img-top" alt="Destinasi 1">
              <div class="card-body">
                <h5 class="card-title">Bukit Sibea-bea</h5>
                <p class="card-text">Bukit sibea-bea destinasi religi yang terletak di Harian Boho, kabupaten Samosir,Sumatra utara,Indonesia.Daya tarik utama objek wisata ini hadirnya sebuah patung Tuhan Yesus di puncak bukit Sibea-bea dengan tinggi 61 m dan selalu di padati pengunjug setiap harinya ,keelokan alam hijau berpadu dengan Danau Toba bisa dinikmati dari sini jalur trek berkeloknya pun terlihat menawan. </p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text"></p>
                   <a href="kamar1.html" class="btn btn-primary">view</a>
                   <a href="Booking.html" class="btn btn-primary">Book Now</a>
                </div>   
                   <p class="card-text"></p>
                   <small class="text-muted"></small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="bukit holbung.jpg" class="card-img-top" alt="Destinasi 2">
              <div class="card-body">
                <h5 class="card-title">Bukit Holbung</h5>
                <p class="card-text">Bukit Holbung terletak di desa Harian,Kabupaten Samosir,Sumatra Utara Bukit holbung merupakan tempat wisata untuk menikmati keindahan Danau Toba.Setiap hari,kawasan ini dikunjungi wisatawan,bahkan kalau Sabtu dan Minggu pengunjung semakin ramai hingga membuat area parkir menjadi penuh. Pengunjung tidak hanya wisatawan lokal saja melainkan juga wisatawan mancanegara yang berasal dari Malaysia,Singapura,dan Negara lainnya.</p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text-">
                    <a href="kamar2.html" class="btn btn-primary">view</a>
                    <a href="Booking.html" class="btn btn-primary">Book Now</a>
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted"></small>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
              <img src="air terjun.jpg" class="card-img-top" alt="Destinasi 3">
              <div class="card-body">
                <h5 class="card-title"></p>
                <div class="d-flex justify-content-between align-items-center">
                  <div class="card-text">Air Terjun Efrata</h5>
                <p class="card-text"> air terjun Efrata berdekatan dengan Menara Pandang Tele Danau Toba.Oleh karena itu tak heran banyak pengunjung lokal dan mancanegara bila singgah ke Tele maupun Danau Toba,juga singgah ke air terjun tersebut.Sementara itu,air terjun Efrata dengan kawasan yang hijau diapit dengan perbukitan membuat setiap pengunjung yang datang ke sana akan terpesona dengan keindahan alamnya.</p>
                      <a href="kamar3.html" class="btn btn-primary">view</a>
                      <a href="Booking.html" class="btn btn-primary">Book Now</a>
                  </div>   
                     <p class="card-text"></p>
                     <small class="text-muted"></small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

<?php include "header.php"; ?>